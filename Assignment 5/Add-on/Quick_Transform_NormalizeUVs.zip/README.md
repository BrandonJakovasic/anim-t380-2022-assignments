This code is used in Blender and allows for the user to apply transforms, and flip the normals
of selected objects by using UI buttons.

To install the script
	Open up Blender and click on the scripting tab at the top
	Click open at the top of the code editor
	Navigate to the "Quick_Transform_NormalizeUVs" location and open it
	Run by pressing the play button at the top
	On the right side of the scene, under the miscellaneous tab, you will see the UI display
	If you don't see any properties on the right side press “n” in the viewport to enable it


To install the add-on
	Open up Blender and click on Edit at the top of the screen
	Click Preferences
	Click Add-ons
	Click Install on the top bar
	Navigate to the .zip file and open it
	Then check the box of the add-on on the screen
	Now return to the main layout tab at the top
	On the right side of the scene, under the miscellaneous tab, you will see the UI
	If you don't see any properties on the right side press “n” in the viewport to enable it
